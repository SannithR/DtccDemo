import logo from './logo.svg';
import './App.css';
import Dtcc from './components/DtccNew/Dtcc2/Dtcc2';

function App() {
  return (
//  <h1>Dtcc Dashboard</h1>
    <Dtcc />
  );
}

export default App;

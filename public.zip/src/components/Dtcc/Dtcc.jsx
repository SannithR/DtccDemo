import React from "react";
import { ArrowDown } from "../ArrowDown/ArrowDown";
import { Avatar } from "../Avatar/Avatar";
import { Banner } from "../Banner/Banner";
import { Divider } from "../Divider/Divider";
import { Domains } from "../Domains/Domains";
import { Domains1 } from "../Domains1/Domains1";
import { DotsVertical } from "../DotsVertical/DotsVertical";
import { Frame37063 } from "../Frame37063/Frame37063";
import { Frame37064 } from "../Frame37064/Frame37064";
import { Home01 } from "../Home01/Home01";
import { IconComponentNode } from "../IconComponentNode/IconComponentNode";
import { LogOut04 } from "../LogOut04/LogOut04";
import { Logo } from "../Logo/Logo";
import { Search } from "../Search/Search";
import { SearchLg } from "../SearchLg/SearchLg";
import { Security } from "../Security/Security";
import { Server } from "../Server/Server";
import { Server1 } from "../Server1/Server1";
import { Server2 } from "../Server2/Server2";
import { Server3 } from "../Server3/Server3";
import { Settings } from "../Settings/Settings";
import { Shield01 } from "../Shield01/Shield01";
import { TableCell } from "../TableCell/TableCell";
import { TableCell1 } from "../TableCell1/TableCell1";
import { TableCell2 } from "../TableCell2/TableCell2";
import { TableCell3 } from "../TableCell3/TableCell3";
import { TableCell4 } from "../TableCell4/TableCell4";
import { TableCell5 } from "../TableCell5/TableCell5";
import { TableCell6 } from "../TableCell6/TableCell6";
import { TrendUp01 } from "../TrendUp01/TrendUp01";
import avatar from "./avatar.png";
import group18299 from "./group-18299.png";
import group18300 from "./group-18300.png";
import group18301 from "./group-18301.png";
import group18302 from "./group-18302.png";
import group18303 from "./group-18303.png";
import screenshot20250409At72957Pm1 from "./screenshot-2025-04-09-at-7-29-57-PM-1.png";
import "./style.css";
import "../../styleguide1.css";

export default function Dtcc ()  {
  return (
    <div className="DTCC">
      <div className="group-wrapper">
        <div className="group">
          <div className="overlap-group">
            <div className="dtcc">
              <div className="frame">
                <div className="navigation">
                  <Logo className="logo-instance" />
                  <div className="menu-name">
                    <div className="menulist">
                      <div className="div">
                        <div className="frame-2">
                          <div className="frame-3">
                            <div className="menuitem">
                              <Home01 className="icon-instance-node" />
                              <div className="text-wrapper">Home</div>
                            </div>

                            <div className="menuitem-2">
                              <img
                                className="img"
                                alt="Group"
                                src={group18302}
                              />

                              <div className="professional-email">
                                Trade Matching
                              </div>
                            </div>

                            <div className="menuitem-2">
                              <img
                                className="group-2"
                                alt="Group"
                                src={group18301}
                              />

                              <div className="text-wrapper">
                                Risk Management
                              </div>
                            </div>

                            <div className="menuitem-2">
                              <Shield01 className="icon-instance-node" />
                              <div className="text-wrapper">Security</div>
                            </div>
                          </div>

                          <div className="section-divider" />

                          <div className="frame-3">
                            <div className="menuitem-2">
                              <img
                                className="group-3"
                                alt="Group"
                                src={group18300}
                              />

                              <div className="text-wrapper">Reporting</div>
                            </div>

                            <div className="menuitem-2">
                              <img
                                className="icon-instance-node"
                                alt="Group"
                                src={group18299}
                              />

                              <div className="text-wrapper">Account</div>
                            </div>

                            <div className="menuitem-2">
                              <img
                                className="group-4"
                                alt="Group"
                                src={group18303}
                              />

                              <div className="buy-more">Support</div>
                            </div>
                          </div>
                        </div>

                        <div className="menuitem-2">
                          <LogOut04 className="icon-instance-node" />
                          <div className="text-wrapper">Signout</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-4">
                  <Banner className="banner-instance" />
                  <div className="CIRCLE">
                    <div className="oval" />

                    <div className="oval-2" />

                    <div className="oval-3" />

                    <div className="oval-4" />
                  </div>

                  <div className="frame-5">
                    <div className="text-wrapper-2">Quick Links</div>

                    <div className="div-2">
                      <div className="services">
                        <Domains className="icon-instance-node-2" />
                        <div className="domains-2">Securities</div>
                      </div>

                      <div className="services-2">
                        <Server className="icon-instance-node-2" />
                        <div className="hosting">Settlement</div>
                      </div>

                      <div className="services">
                        <Security className="icon-instance-node-2" />
                        <div className="security-2">Risk Analytics</div>
                      </div>

                      <div className="services">
                        <Settings className="icon-instance-node-2" />
                        <div className="proff-email">Corporate Actions</div>
                      </div>

                      <div className="services">
                        <IconComponentNode className="icon-instance-node-2" />
                        <div className="text-wrapper-3">More</div>
                      </div>
                    </div>
                  </div>

                  <div className="table">
                    <div className="card-header">
                      <div className="content">
                        <div className="avatar-and-text">
                          <div className="div-3">
                            <div className="text-and-badge">
                              <div className="text">Products Table</div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <Divider className="icon-instance-node-3" />
                    </div>

                    <div className="filters-bar">
                      <div className="content-2">
                        <div className="button-group">
                          <div className="button-group-base">
                            <div className="text-2">All Instruments</div>
                          </div>

                          <div className="div-wrapper">
                            <div className="text-3">Fixed Income</div>
                          </div>

                          <div className="button-group-base-2">
                            <div className="text-3">Corporate Bonds</div>
                          </div>

                          <div className="button-group-base-3">
                            <div className="text-3">Derivatives</div>
                          </div>

                          <div className="button-group-base-4">
                            <div className="text-3">Market Data</div>
                          </div>
                        </div>

                        <div className="actions" />
                      </div>
                    </div>

                    <div className="content-3">
                      <div className="column">
                        <div className="table-header-cell">
                          <div className="table-header">
                            <div className="text-4">Security Instrument</div>

                            <ArrowDown className="arrow-down" />
                          </div>
                        </div>

                        <div className="table-cell">
                          <Avatar className="icon-instance-node-4" />
                          <div className="div-4">
                            <div className="text-5">Fixed Income Security</div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <Domains1 className="icon-instance-node-4" />
                          <div className="div-4">
                            <div className="text-5">Corporate Bond</div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <Server1 className="icon-instance-node-4" />
                          <div className="div-4">
                            <div className="text-5">Market Data Services</div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <Server2 className="icon-instance-node-4" />
                          <div className="div-4">
                            <div className="text-5">Derivatives Platform</div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <img className="avatar-2" alt="Avatar" src={avatar} />

                          <div className="text-and-supporting">
                            <div className="text-5">
                              Trade Confirmation Service
                            </div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <img className="avatar-3" alt="Avatar" src={avatar} />

                          <div className="text-and-supporting-2">
                            <div className="text-5">
                              Professional Email Package
                            </div>

                            <p className="supporting-text">
                              Expiring on 05 Jan 2025
                            </p>
                          </div>
                        </div>

                        <div className="table-cell">
                          <Server3 className="icons-server" />
                          <div className="text-and-supporting-3">
                            <div className="text-5">Linux Essential plan</div>

                            <p className="supporting-text">
                              Expiring on 05 Jan 2025
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="column-2">
                        <div className="table-header-cell">
                          <div className="table-header">
                            <div className="text-4">Status</div>
                          </div>
                        </div>

                        <div className="table-cell-2">
                          <div className="badge">
                            <div className="text-6">Expired</div>
                          </div>
                        </div>

                        <div className="table-cell-2">
                          <div className="badge-2">
                            <div className="text-7">Expiring soon</div>
                          </div>
                        </div>

                        <div className="table-cell-2">
                          <div className="badge-3">
                            <div className="text-8">Active</div>
                          </div>
                        </div>

                        <div className="table-cell-2">
                          <div className="badge-3">
                            <div className="text-8">Active</div>
                          </div>
                        </div>

                        <div className="table-cell-2">
                          <div className="badge-2">
                            <div className="text-9">Expiring soon</div>
                          </div>
                        </div>

                        <div className="table-cell-2">
                          <div className="badge-3">
                            <div className="text-8">Active</div>
                          </div>
                        </div>

                        <div className="table-cell-2">
                          <div className="badge-3">
                            <div className="text-8">Active</div>
                          </div>
                        </div>
                      </div>

                      <div className="div-3">
                        <div className="table-header-cell">
                          <div className="table-header">
                            <div className="text-4">Utilization</div>
                          </div>
                        </div>

                        <div className="table-cell-2">
                          <div className="text-10">NA</div>
                        </div>

                        <div className="table-cell-2">
                          <div className="text-10">NA</div>
                        </div>

                        <div className="table-cell">
                          <div className="progress-bar">
                            <div className="progress-wrapper">
                              <div className="progress" />
                            </div>

                            <div className="percentage">30%</div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <div className="progress-bar">
                            <div className="progress-wrapper">
                              <div className="progress-2" />
                            </div>

                            <div className="percentage">80%</div>
                          </div>
                        </div>

                        <div className="table-cell-2">
                          <div className="text-10">NA</div>
                        </div>

                        <div className="table-cell">
                          <div className="progress-bar">
                            <div className="progress-wrapper">
                              <div className="progress-3" />
                            </div>

                            <div className="percentage">10%</div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <div className="progress-bar">
                            <div className="progress-wrapper">
                              <div className="progress-4" />
                            </div>

                            <div className="percentage">40%</div>
                          </div>
                        </div>
                      </div>

                      <div className="column-3">
                        <div className="table-header-cell">
                          <div className="table-header-2">
                            <div className="text-4">Auto Settlement</div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <div className="toggle">
                            <div className="toggle-base">
                              <div className="button" />
                            </div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <div className="toggle">
                            <div className="button-wrapper">
                              <div className="button" />
                            </div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <div className="toggle">
                            <div className="toggle-base">
                              <div className="button" />
                            </div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <div className="toggle">
                            <div className="toggle-base">
                              <div className="button" />
                            </div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <div className="toggle">
                            <div className="toggle-base">
                              <div className="button" />
                            </div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <div className="toggle">
                            <div className="toggle-base">
                              <div className="button" />
                            </div>
                          </div>
                        </div>

                        <div className="table-cell">
                          <div className="toggle">
                            <div className="toggle-base">
                              <div className="button" />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="div-4">
                        <div className="table-header-cell-2" />

                        <TableCell className="table-cell-instance" />
                        <TableCell1 className="table-cell-instance" />
                        <TableCell2 className="table-cell-instance" />
                        <TableCell3 className="table-cell-instance" />
                        <TableCell4 className="table-cell-instance" />
                        <TableCell5 className="icon-instance-node-3" />
                        <TableCell6 className="table-cell-3" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="side">
                  <div className="search-2">
                    <div className="ellipse" />

                    <div className="div-4">
                      <div className="frame-6">
                        <TrendUp01 className="icon-instance-node" />
                        <div className="boost">Securing</div>
                      </div>

                      <div className="your-business-with-a">
                        Markets, Powering
                        <br />
                        Trust.
                      </div>
                    </div>

                    <div className="frame-7">
                      <div className="frame-8">
                        <Search className="search-instance" />
                        <div className="search-domain">Find resources</div>
                      </div>

                      <div className="BUTTON">
                        <div className="shop-now">SEARCH</div>

                        <SearchLg className="search-lg" />
                      </div>
                    </div>
                  </div>

                  <div className="frame-9">
                    <div className="div-2">
                      <div className="require-renewal">Actions Required</div>

                      <div className="text-wrapper-4">See All</div>
                    </div>

                    <div className="domains-3">
                      <div className="domain-overview">
                        <div className="frame-10">
                          <div className="frame-11">
                            <div className="frame-12">
                              <div className="text-wrapper-5">
                                Corporate Action Elections
                              </div>

                              <Frame37063 className="frame-13" />
                            </div>

                            <div className="frame-14">
                              <div className="frame-wrapper">
                                <div className="expired-wrapper">
                                  <div className="text-wrapper-6">Pending</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <DotsVertical className="icon-instance-node" />
                      </div>

                      <div className="domain-overview-2">
                        <div className="frame-10">
                          <div className="frame-11">
                            <div className="frame-15">
                              <div className="text-wrapper-5">
                                Settlement Exceptions
                              </div>

                              <Frame37063 className="frame-13" />
                            </div>

                            <div className="frame-14">
                              <div className="frame-wrapper">
                                <div className="expiring-soon-wrapper">
                                  <div className="expiring-soon">
                                    In Progress
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <DotsVertical className="icon-instance-node" />
                      </div>

                      <div className="domain-overview-2">
                        <div className="frame-10">
                          <div className="frame-11">
                            <div className="frame-16">
                              <div className="text-wrapper-5">
                                Corporate Elections
                              </div>

                              <Frame37063 className="frame-13" />
                            </div>

                            <div className="frame-14">
                              <div className="frame-wrapper">
                                <div className="expiring-soon-wrapper">
                                  <div className="expiring-soon">
                                    In Progress
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <DotsVertical className="icon-instance-node" />
                      </div>

                      <div className="domain-overview-2">
                        <div className="frame-10">
                          <div className="frame-11">
                            <div className="frame-15">
                              <div className="text-wrapper-5">
                                Settlement Exceptions
                              </div>

                              <Frame37063 className="frame-13" />
                            </div>

                            <div className="frame-14">
                              <div className="frame-wrapper">
                                <div className="expiring-soon-wrapper">
                                  <div className="expiring-soon">
                                    In Progress
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <DotsVertical className="icon-instance-node" />
                      </div>

                      <div className="domain-overview-2">
                        <div className="frame-10">
                          <div className="frame-11">
                            <div className="frame-17">
                              <div className="text-wrapper-5">
                                Margin Requirements
                              </div>

                              <Frame37064 className="frame-13" />
                            </div>

                            <div className="frame-14">
                              <div className="frame-wrapper">
                                <div className="expired-wrapper">
                                  <div className="text-wrapper-6">On Hold</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <DotsVertical className="icon-instance-node" />
                      </div>

                      <div className="domain-overview-3">
                        <div className="frame-10">
                          <div className="frame-11">
                            <div className="frame-18">
                              <div className="text-wrapper-5">
                                Regulatory Reporting Deadlines
                              </div>

                              <Frame37064 className="frame-13" />
                            </div>

                            <div className="frame-14">
                              <div className="frame-wrapper">
                                <div className="frame-19">
                                  <div className="text-wrapper-6">Expired</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        <DotsVertical className="icon-instance-node" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <img
              className="screenshot"
              alt="Screenshot"
              src={screenshot20250409At72957Pm1}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
